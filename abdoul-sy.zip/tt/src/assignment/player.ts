import {Synthesizer} from '../synthesizer/Synthesizer';
import {Track, Note} from '../types';
import {PlayerController, Sequence, ChannelNote} from './sharedTypes';
import * as Utils from './playerUtil';
import {buildTimer, delayAsync} from '../util';
import {PlayerInterface} from './playerInterface';
import {Channel} from '../synthesizer/Channel';
import {prepareTickHandler} from './tick';

function makePlayerController(tracks: ReadonlyArray<Track>): PlayerController {
  return {
    runningTime: 0,
    tracks,
    next: 1,
    currentTimepoint: 0,
    timePoints: [],
    songTime: Utils.getSongTimeFromTracksMilliSecond(tracks),
    isRunning: false,
    interrupt: false
  };
}

async function play(ctrl: PlayerController, timer: () => number, synthesizer: Synthesizer) {
  try {
    const {timedSequence, sortedTimes, $ends} = makeSimulationTrack(ctrl, synthesizer);
    ctrl.runningTime = timer(); //initial timing
    ctrl.timePoints = sortedTimes;

    for (let i = 0; i < sortedTimes.length; i = i + (ctrl?.next ?? 1)) {
      ctrl.currentTimepoint = i;
      if (ctrl && (ctrl?.next ?? 0) > 1) {
        ctrl.next = 1; // reset skip
        for (const [k, v] of [...$ends]) {
          for (let l = 0; l < v.length; l++) {
            try {
              v[l].ch.isPlaying && (await stopNote(v[l].ch));
            } catch (e) {
              console.warn({e});
            }
          }
        }
      }

      ctrl.isRunning = await sequenceOfNotesAtOneTime(
        ctrl,
        timer,
        timedSequence.get(sortedTimes[i]),
        $ends,
        sortedTimes[i]
      );
      ctrl.runningTime = timer(); //initial timing
      if (!ctrl.isRunning || ctrl.interrupt) {
        for (const [k, v] of [...$ends]) {
          for (let l = 0; l < v.length; l++) {
            try {
              v[l].ch.isPlaying && (await stopNote(v[l].ch));
            } catch (e) {
              console.warn({e});
            }
          }
        }
        break;
      }
      ctrl.runningTime = timer(); //update timing
    }
    ctrl.isRunning = false;
  } catch (e) {
    console.error(e);
    ctrl.isRunning = false;
  }
}

async function sequenceOfNotesAtOneTime(
  ctrl: PlayerController,
  timer: () => number,
  entries:
    | {
        delay: number;
        notes?: Array<ChannelNote>;
      }
    | undefined,
  ends: Map<number, Array<ChannelNote> | undefined>,
  currentTime: number
): Promise<boolean> {
  let keepPlaying = true;

  try {
    if (!entries) return false;
    const {notes, delay} = entries;
    if (!notes && !delay) {
      return false;
    }
    for (const note of ends.get(currentTime) ?? []) {
      await stopNote(note.ch);
    }
    if (!notes && delay) {
      await delayAsync(delay);
      return true;
    }

    for (const startNote of notes || []) {
      if (!keepPlaying) return false;
      keepPlaying = await update(ctrl, timer, startNote);
    }

    await delayAsync(delay ?? 0);

    for (const note of ends.get(currentTime + delay) ?? []) {
      await stopNote(note.ch);
    }
  } catch (e) {
    console.error(e);
    keepPlaying = false;
  }

  return keepPlaying;
}

async function update(
  ctrl: PlayerController,
  timer: () => number,
  entry?: {ch: Channel; note: Note}
): Promise<boolean> {
  ctrl.runningTime = timer(); //+ (entry?.note?.duration ?? 0);
  return !!(entry && (await playNote(entry.ch, entry.note)));
}

async function stopNote(ch: Channel) {
  ch.stopNote();
}

async function playNote(ch: Channel, note: Note): Promise<boolean> {
  return ch?.playNote(note.name, note.velocity);
}

// the $variable convention just tells the variable is explicitely mutable
// even when passed around functions
function makeSimulationTrack(
  ctrl: PlayerController,
  synthetiser: Synthesizer,
  offset = 0
): {
  timedSequence: Map<number, Sequence>;
  sortedTimes: number[];
  $ends: Map<number, Array<{ch: Channel; note: Note}>>;
} {
  let sortedTimePoints: Array<number>;
  const $timedSequence = new Map<number, Sequence>();
  const $timedSimulationFlat = new Map<number, Array<ChannelNote>>();
  const $listOfTimePoints = new Set<number>();
  const $ends = new Map<number, Array<{ch: Channel; note: Note}>>();
  Utils.storeNotesByChannel(ctrl, $timedSimulationFlat, synthetiser, $listOfTimePoints, $ends);

  sortedTimePoints = [...$listOfTimePoints].sort((a, b) => a - b).filter((t) => t >= offset);
  sortedTimePoints.forEach(prepareTickHandler($timedSequence, $timedSimulationFlat, offset));
  return {timedSequence: $timedSequence, sortedTimes: sortedTimePoints, $ends};
}

export function player(synthesizer: Synthesizer, tracks: ReadonlyArray<Track>): PlayerInterface {
  const controller = makePlayerController(tracks);
  return {
    play: async () => {
      const timer = buildTimer();
      controller.isRunning = true;
      await play(controller, timer, synthesizer);
    },
    getTime: () => {
      return controller.runningTime;
    },
    skipToTimestamp: async (timestamp) => {
      const idx = controller.timePoints?.findIndex((v) => v > timestamp);
      controller.next = idx ?? 1 - (controller.currentTimepoint ?? 1);
    }
  };
}

async function gracefulStopIfneeded(
  ctrl: PlayerController,
  ends: Map<number, Array<ChannelNote> | undefined>,
  currentTime: number
) {
  if (ctrl.interrupt) {
    const notesEnding = ends.get(currentTime) ?? [];
    for (const note of notesEnding) {
      await stopNote(note.ch);
    }
  }
  ctrl.isRunning = false;
  ctrl.runningTime = 0; //update timing
}
