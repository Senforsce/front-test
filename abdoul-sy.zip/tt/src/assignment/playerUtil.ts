import {Synthesizer} from '../synthesizer/Synthesizer';
import {Track, Note} from '../types';
import {
  PlayerController,
  Sequence,
  ChannelNote,
  MutableAnchor,
  MutableStackOfChannelNote,
  MutableTime
} from './sharedTypes';

import {Channel} from '../synthesizer/Channel';

export function getSongTimeFromTracksMilliSecond(tracks: ReadonlyArray<Track>): number {
  let songTime = 0;

  tracks.forEach((track) => {
    const notes = track.notes;

    const sortedNotes = [...notes].sort((a, b) => {
      return a.time - b.time;
    });

    songTime = Math.max(
      sortedNotes[sortedNotes.length - 1].time + sortedNotes[sortedNotes.length - 1].duration,
      songTime
    );
  });

  return songTime;
}

export function storeNotesByChannel(
  ctrl: PlayerController,
  $timedMap: Map<number, Array<{ch: Channel; note: Note}>>,
  synthesizer: Synthesizer,
  inventory: Set<number>,
  $ends: Map<number, Array<{ch: Channel; note: Note}>>
) {
  for (const track of ctrl.tracks) {
    const channel = synthesizer.getChannel(track.instrumentName);

    for (const note of track.notes) {
      const simulation = {
        ch: channel,
        note
      };

      $timedMap.set(note.time, ($timedMap.get(note.time) ?? []).concat(simulation));
      inventory.add(note.time);
      const endNote = note.time + note.duration;
      inventory.add(endNote);
      $ends.set(endNote, ($ends.get(note.time + note.duration) ?? []).concat(simulation));
    }
  }
}

export function isTheCurrentTimeTheSameAsPredictedEndOfPreviousNote(val: number, anchor: MutableAnchor) {
  return val === anchor.nextEvent;
}

export function isTheCurrentTimeAbovePredictedEndOfPreviousNote(val: number, anchor: MutableAnchor) {
  return val > anchor.nextEvent;
}

export function getStackPenultimateItem(stack: MutableStackOfChannelNote) {
  return stack.current[stack.current.length - 2];
}

export function popStack($stack: MutableStackOfChannelNote) {
  return $stack.current.pop();
}

export function setStack($stack: MutableStackOfChannelNote, items: ChannelNote[]) {
  return ($stack.current = items);
}

export function copyStack(stack: MutableStackOfChannelNote): MutableStackOfChannelNote {
  return {
    current: stack.current.map((cn) => {
      return cn;
    })
  };
}

export function getStackLastItem(stack: MutableStackOfChannelNote) {
  return stack.current[stack.current.length - 1];
}

export function isPreviousNoteInStackNeedCutting(
  stack: MutableStackOfChannelNote,
  elems: Array<ChannelNote | undefined>,
  val: number,
  anchor: MutableAnchor,
  previousAnchor: MutableAnchor,
  bufferLength: number
) {
  // IF
  // there is a stack AND
  // a note AND
  // position in time is further than projected next note AND
  // the previous note time is bigger than the duration of this note
  return (
    stack.current.length &&
    elems.length &&
    val >= anchor.nextEvent &&
    previousAnchor.nextEvent < anchor.nextEvent &&
    bufferLength > val
  );
}

export function isCurrentNotePlayingDuringThePreviousOne(
  val: number,
  stack: MutableStackOfChannelNote,
  bufferLength: number
): boolean {
  const elem = stack.current[stack.current.length - 1];
  if (!elem) return false;

  return stack.current.length > 0 && val < elem.note.time + elem.note.duration;
}

export function isNoteAtItsEnd(val: number, stack: MutableStackOfChannelNote): boolean {
  const elem = getStackLastItem(stack);
  if (!elem) return false;
  return stack.current.length > 0 && val === elem.note.time + elem.note.duration;
}

export function setCurrentAnchor(
  val: number,
  $anchor: MutableAnchor,
  $previousAnchor: MutableAnchor,
  elems: ChannelNote[] | undefined,
  $previousTime: MutableTime
) {
  $previousAnchor = $anchor;
  $anchor.nextEvent =
    val +
    (elems ?? [])
      .filter((n) => n?.note.duration)
      .reduce((prev, cur) => {
        return Math.min(prev, cur?.note.duration);
      }, elems![0].note.duration);
  $previousTime.time = val;
}

export function atLeastOneChannelNote(f: ChannelNote[] | undefined) {
  return f && (f?.length ?? 0) > 0;
}

export function getChannelNotes(f: ChannelNote[] | undefined): ChannelNote[] {
  console.assert(atLeastOneChannelNote(f), 'There should be at least a channelNote mapping');
  return f as ChannelNote[];
}

export function resetStack($stack: MutableStackOfChannelNote) {
  $stack = {current: []};
}

export function addToStack($stack: MutableStackOfChannelNote, elems?: ChannelNote[]) {
  elems?.length && ($stack.current = $stack.current.concat(elems));
}

export function mutateSequenceToInsertDelayAtBeginning(
  index: number,
  val: number,
  timedSequence: Map<number, Sequence>,
  $anchor: MutableAnchor,
  offset = 0
) {
  if (firstElementInSequenceStartsLater(index, val)) {
    mutateSequenceToInsertDelayAtTime(val - offset, timedSequence, $anchor, offset);
  }
}

export function mutateSequenceToInsertDelayAtTime(
  val: number,
  timedSequence: Map<number, Sequence>,
  $anchor: MutableAnchor,
  time: number
) {
  timedSequence.set(time, {delay: val});
  $anchor.nextEvent = val + time; //now
}

export function addToSequence(
  $stack: MutableStackOfChannelNote,
  elems: ChannelNote[],
  delay: number,
  notes: ChannelNote[],
  $timedSequence: Map<number, Sequence>,
  val: number,
  anchor: MutableAnchor,
  previousAnchor: MutableAnchor,
  previousTime: MutableTime,
  doNotSaveTime = false
) {
  elems.length && addToStack($stack, elems);
  !doNotSaveTime && setCurrentAnchor(val, anchor, previousAnchor, elems, previousTime);

  elems &&
    $timedSequence.set(val, {
      delay,
      notes: notes
    });
}

export function decreaseDurationInStack(
  $stack: MutableStackOfChannelNote,
  currentTime: number,
  value: number
) {
  setStack(
    $stack,
    $stack.current
      .map((e) => {
        e.note['duration'] = e.note['duration'] - value;
        e.note['time'] = currentTime;
        return e;
      })
      .filter((cn) => {
        return cn.note.duration > 0;
      })
  );
}

export function alterDurationInStack($stack: MutableStackOfChannelNote, value: number) {
  setStack(
    $stack,
    $stack.current
      .map((e) => {
        e.note['duration'] = value;
        return e;
      })
      .filter((cn) => {
        return cn.note.duration > 0;
      })
  );
}

export function replaceDelayValueInCurrentStack(
  $stack: MutableStackOfChannelNote,
  key: 'delay',
  value: number
) {
  setStack(
    $stack,
    $stack.current.map((e) => {
      e[key] = value;
      return e;
    })
  );
}

export function firstElementInSequenceStartsLater(index: number, val: number): boolean {
  return index === 0 && val > 0;
}
