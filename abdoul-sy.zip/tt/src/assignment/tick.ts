import {ChannelNote, MutableAnchor, MutableStackOfChannelNote, MutableTime, Sequence} from './sharedTypes';
import * as Utils from './playerUtil';

export function prepareTickHandler(
  $timedSequence: Map<number, Sequence>,
  $timedSimulationFlat: Map<number, Array<ChannelNote>>,
  offset = 0
) {
  let stack: MutableStackOfChannelNote = {current: []}; // stack to play notes simultaneously
  let anchor: MutableAnchor = {nextEvent: offset}; //Anchor to the outermost Bracket
  let previousTime: MutableTime = {time: offset}; // Previous time being treated
  let previousAnchor: MutableAnchor = {nextEvent: offset}; //anchor to Innermost bracket (time in ms)

  return function onTick(currentTime: number, i: number) {
    Utils.mutateSequenceToInsertDelayAtBeginning(i, currentTime, $timedSequence, anchor, offset);

    const maybeChannelNotes = $timedSimulationFlat.get(currentTime);

    if (Utils.atLeastOneChannelNote(maybeChannelNotes)) {
      if (currentTime > anchor.nextEvent) {
        //we need to insert a delay as we have a delay between notes
        Utils.mutateSequenceToInsertDelayAtTime(
          currentTime - anchor.nextEvent,
          $timedSequence,
          anchor,
          anchor.nextEvent
        );
      }
      // If there is an element at this time
      const channelNotes = Utils.getChannelNotes(maybeChannelNotes);

      Utils.decreaseDurationInStack(stack, currentTime, currentTime - previousTime.time);

      if (stack.current.length > 0) {
        const prev = $timedSequence.get(previousTime.time);
        prev &&
          $timedSequence.set(previousTime.time, {delay: currentTime - previousTime.time, notes: prev.notes});
      }
      $timedSequence.set(currentTime, {
        delay: channelNotes.reduce((prev, curr) => {
          return Math.min(prev, curr.note.duration);
        }, channelNotes[0].note.duration),
        notes: channelNotes
      });
      Utils.addToStack(stack, channelNotes);

      Utils.setCurrentAnchor(currentTime, anchor, previousAnchor, channelNotes, previousTime);
    } else {
      // it is probably a delay or a channel note should be closed
      Utils.decreaseDurationInStack(stack, currentTime, currentTime - previousTime.time);

      if (stack.current.length > 0) {
        $timedSequence.set(currentTime, {
          delay: stack.current.reduce((prev, curr) => {
            return Math.min(prev, curr.note.duration);
          }, stack.current[0].note.duration),
          notes: []
        });

        Utils.setCurrentAnchor(currentTime, anchor, previousAnchor, stack.current, previousTime);
      }
    }
  };
}
