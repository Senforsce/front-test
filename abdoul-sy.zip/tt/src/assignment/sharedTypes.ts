import {Track, Note} from '../types';
import {Channel} from '../synthesizer/Channel';

export type PlayerController = {
  runningTime: number;
  songTime: number;
  isRunning: boolean;
  currentTimepoint?: number;
  timePoints?: number[];
  next?: number;
  tracks: ReadonlyArray<Track>;
  interrupt: boolean;
};

export type ChannelNote = {ch: Channel; note: Note; delay?: number; shouldStopNote?: boolean};
export type Sequence = {delay: number; notes?: Array<ChannelNote>};
export type MutableAnchor = {nextEvent: number};
export type MutableTime = {time: number};
export type MutableStack<T> = {current: T[]};
export type MutableStackOfChannelNote = MutableStack<ChannelNote>;
