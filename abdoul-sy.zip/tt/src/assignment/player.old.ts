import {Synthesizer} from '../synthesizer/Synthesizer';
import {Track, Note} from '../types';
import {PlayerController, Sequence, ChannelNote} from './sharedTypes';
import * as Utils from './playerUtil';
import {buildTimer, delayAsync} from '../util';
import {PlayerInterface} from './playerInterface';
import {Channel} from '../synthesizer/Channel';
import {prepareTickHandler} from './tick';

function makePlayerController(tracks: ReadonlyArray<Track>): PlayerController {
  return {
    runningTime: 0,
    tracks,
    next: 1,
    currentTimepoint: 0,
    timePoints: [],
    songTime: Utils.getSongTimeFromTracksMilliSecond(tracks),
    isRunning: false,
    interrupt: false
  };
}

class DelayQueue {
  private queue: (() => Promise<void>)[] = [];
  private processing = false;

  async add(delay: number) {
    return new Promise<void>((resolve) => {
      this.queue.push(async () => {
        await delayAsync(delay);
        resolve();
      });
      this.processQueue();
    });
  }

  private async processQueue() {
    if (this.processing) return;
    this.processing = true;

    while (this.queue.length > 0) {
      const task = this.queue.shift();
      if (task) await task();
    }

    this.processing = false;
  }
}

const delayQueue = new DelayQueue();

const identity: (val: number, index: number, v: number[]) => boolean = (v) => true;

async function play(
  ctrl: PlayerController,
  timer: () => number,
  synthesizer: Synthesizer,
  replay?: boolean,
  filterFn?: (val: number, index: number, v: number[]) => boolean
) {
  try {
    const run = async () => {
      const simulation = makeSimulationTrack(ctrl, synthesizer, timer());
      const {timedSequence, sortedTimes, $ends} = simulation;
      const filterFunc = filterFn ?? identity;
      ctrl.timePoints = sortedTimes;

      const filteredTimes = sortedTimes.filter(filterFunc);
      const lengthOfPartition = filteredTimes.length;
      for (let i = 0; i < lengthOfPartition; i = i + (ctrl?.next ?? 1)) {
        if (!ctrl.isRunning || ctrl.interrupt) {
          return {timedSequence, sortedTimes, $ends};
        }
        if (ctrl && (ctrl?.next ?? 0) > 1) ctrl.next = 1; // reset skip
        ctrl.runningTime = timer(); //initial timing
        ctrl.currentTimepoint = i;
        const sequence = await sequenceOfNotesAtOneTime(
          ctrl,
          timer,
          timedSequence.get(filteredTimes[i]),
          $ends,
          filteredTimes[i]
        );
        const keepPlaying = sequence.keepPlaying;
        if (!ctrl.isRunning || ctrl.interrupt) {
          return {timedSequence, sortedTimes, $ends};
        }
        ctrl.runningTime = timer(); //update timing
      }
      for (const [k, v] of [...$ends]) {
        for (let l = 0; l < v.length; l++) {
          try {
            await stopNote(v[l].ch, true);
            console.log({attempting: v});
          } catch (e) {
            console.warn({e});
          }
        }
      }
      return {timedSequence, sortedTimes, $ends};
    };

    const {timedSequence, sortedTimes, $ends} = await run();
    ctrl.isRunning = false;
  } catch (e) {
    console.error(e);
    ctrl.isRunning = false;
  }
}

async function sequenceOfNotesAtOneTime(
  ctrl: PlayerController,
  timer: () => number,
  entries:
    | {
        delay: number;
        notes?: Array<ChannelNote>;
      }
    | undefined,
  ends: Map<number, Array<ChannelNote> | undefined>,
  currentTime: number
): Promise<{
  keepPlaying: boolean;
  playing?: Map<string, ChannelNote | undefined>;
}> {
  let keepPlaying = true;
  let absoluteDelay = 0;
  let stackOfPlayingNotes = new Map<string, ChannelNote>();

  try {
    if (!entries) return {keepPlaying: false};
    const {notes, delay} = entries;
    if (!notes && !delay) {
      return {keepPlaying: false, playing: stackOfPlayingNotes};
    }
    for (const note of ends.get(currentTime) ?? []) {
      await stopNote(note.ch);
      stackOfPlayingNotes.delete(note.ch.instrumentName + note.note.name);
    }
    if (!notes && delay) {
      absoluteDelay += delay;
      try {
        await delayQueue.add(delay);
      } catch (e) {
        console.warn(e);
      }

      return {keepPlaying: true, playing: stackOfPlayingNotes};
    }

    for (const startNote of notes || []) {
      if (!keepPlaying) return {keepPlaying: false, playing: stackOfPlayingNotes};
      keepPlaying = await update(ctrl, timer, startNote);
      notes?.forEach((n) => {
        stackOfPlayingNotes.set(n.ch.instrumentName + n.note.name, n);
      });
    }

    if (delay > 0) await delayQueue.add(delay);

    for (const note of ends.get(currentTime + delay) ?? []) {
      await stopNote(note.ch);
    }
  } catch (e) {
    console.error(e);
    keepPlaying = false;
  }

  return {keepPlaying: false, playing: stackOfPlayingNotes};
}

async function update(
  ctrl: PlayerController,
  timer: () => number,
  entry?: {ch: Channel; note: Note}
): Promise<boolean> {
  ctrl.runningTime = timer(); //+ (entry?.note?.duration ?? 0);
  return !!(entry && (await playNote(entry.ch, entry.note)));
}

async function stopNote(ch: Channel, a?: boolean) {
  ch.stopNote();
}

async function playNote(ch: Channel, note: Note): Promise<boolean> {
  return ch?.playNote(note.name, note.velocity);
}

// the $variable convention just tells the variable is explicitely mutable
// even when passed around functions
function makeSimulationTrack(
  ctrl: PlayerController,
  synthetiser: Synthesizer,
  offset = 0
): {
  timedSequence: Map<number, Sequence>;
  sortedTimes: number[];
  $ends: Map<number, Array<{ch: Channel; note: Note}>>;
} {
  let sortedTimePoints: Array<number>;
  const $timedSequence = new Map<number, Sequence>();
  const $timedSimulationFlat = new Map<number, Array<ChannelNote>>();
  const $listOfTimePoints = new Set<number>();
  const $ends = new Map<number, Array<{ch: Channel; note: Note}>>();
  Utils.storeNotesByChannel(ctrl, $timedSimulationFlat, synthetiser, $listOfTimePoints, $ends);

  sortedTimePoints = [...$listOfTimePoints].sort((a, b) => a - b).filter((t) => t >= offset);
  sortedTimePoints.forEach(prepareTickHandler($timedSequence, $timedSimulationFlat, offset));
  return {timedSequence: $timedSequence, sortedTimes: sortedTimePoints, $ends};
}

export function player(synthesizer: Synthesizer, tracks: ReadonlyArray<Track>): PlayerInterface {
  const controller = makePlayerController(tracks);
  return {
    play: async () => {
      const timer = buildTimer();
      controller.isRunning = true;
      await play(controller, timer, synthesizer);
    },
    getTime: () => {
      return controller.runningTime;
    },
    skipToTimestamp: async (timestamp) => {
      controller.next = 150;
    }
  };
}

async function gracefulStopIfneeded(
  ctrl: PlayerController,
  ends: Map<number, Array<ChannelNote> | undefined>,
  currentTime: number
) {
  if (ctrl.interrupt) {
    const notesEnding = ends.get(currentTime) ?? [];
    for (const note of notesEnding) {
      await stopNote(note.ch);
    }
  }
  ctrl.isRunning = false;
  ctrl.runningTime = 0; //update timing
}
