export const TIME_RANGE = 10 * 1000; // visualize over 10s.
export const LEFT_OFFSET = 200; // px

